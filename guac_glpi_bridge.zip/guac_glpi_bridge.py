#!/usr/bin/env python3
"""
Ponte GLPI -> Guacamole
=======================
O link externo do GLPI chama este servico com o nome do computador:

    http://IP-DO-GUACAMOLE:8096/?host=[NAME]

O servico procura no Guacamole uma conexao com esse nome. Se ela nao existir,
cria a conexao RDP (NOME.dominio) e redireciona o navegador direto para a sessao.
Nao precisa de API do GLPI, cron, Apache nem bibliotecas extras (so Python 3).

Uso (no servidor do Guacamole):
    1. Preencha o bloco "CONFIGURE AQUI" abaixo.
    2. python3 guac_glpi_bridge.py test PC-TESTE     -> testa sem criar nada
    3. sudo python3 guac_glpi_bridge.py install      -> instala como servico
    4. No GLPI, use o link: http://IP-DO-GUACAMOLE:8096/?host=[NAME]

Outros comandos:
    sudo python3 guac_glpi_bridge.py uninstall       -> remove o servico
    python3 guac_glpi_bridge.py run                  -> roda em primeiro plano
    journalctl -u guac-glpi -f                       -> acompanha o log
"""

# =========================== CONFIGURE AQUI ===========================

# Como ESTE script acessa o Guacamole (no proprio servidor, use 127.0.0.1)
GUAC_URL = "http://127.0.0.1:8095"

# Como os TECNICOS acessam o Guacamole pelo navegador
GUAC_PUBLIC_URL = "http://10.1.181.90:8095"

# Usuario do Guacamole usado pelo script (crie em Configuracoes > Usuarios,
# com a permissao "Administrar sistema")
GUAC_USER = "svc-sync"
GUAC_PASS = "Q!W@E#q1w2e3"

# Dominio DNS dos computadores: a conexao usa NOME.DOMINIO como host.
# Deixe "" para usar so o nome do computador.
DOMAIN_DNS = "grupovia.lan"

# Pasta do Guacamole onde as conexoes novas sao criadas (criada se nao existir)
CONN_GROUP = "GLPI"

# Grupo de USUARIOS do Guacamole que recebe acesso as conexoes novas
# (Configuracoes > Grupos). Deixe "" para nao conceder automaticamente.
USER_GROUP = ""

# Parametros RDP das conexoes criadas
RDP_PORT = "3389"
RDP_SECURITY = "nla"          # nla | any | tls | rdp
RDP_IGNORE_CERT = True

# True somente se o login no Guacamole for feito com a conta do AD (LDAP):
# repassa o usuario e a senha do Guacamole para o Windows.
# False = o Windows pede usuario e senha ao conectar.
PASS_CREDENTIALS = False
RDP_DOMAIN = ""               # dominio NetBIOS (ex.: "EMPRESA"), usado com PASS_CREDENTIALS

# So cria a conexao se o nome do computador resolver no DNS deste servidor
CHECK_DNS = True

# Porta deste servico e redes que podem usa-lo
LISTEN_ADDR = "0.0.0.0"
LISTEN_PORT = 8096
ALLOWED_NETWORKS = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"]

# ======================================================================

import base64
import html
import ipaddress
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SERVICE = "guac-glpi"
SERVICE_USER = "guacglpi"
INSTALL_DIR = "/opt/guac-glpi"
INSTALL_FILE = os.path.join(INSTALL_DIR, "guac_glpi_bridge.py")
UNIT_FILE = f"/etc/systemd/system/{SERVICE}.service"
VALID_NAME = re.compile(r"^[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?$")
NETWORKS = [ipaddress.ip_network(n) for n in ALLOWED_NETWORKS]


def log(msg):
    print(msg, flush=True)


class NotInDNS(Exception):
    pass


# --------------------------- API do Guacamole ---------------------------

class Guacamole:
    def __init__(self):
        self.lock = threading.Lock()
        self.token = None
        self.ds = None

    @staticmethod
    def _http(method, url, form=None, body=None, token=None):
        headers, data = {}, None
        if body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        elif form is not None:
            data = urllib.parse.urlencode(form).encode()
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        if token:
            headers["Guacamole-Token"] = token
            url += ("&" if "?" in url else "?") + "token=" + urllib.parse.quote(token)
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read()
        return json.loads(raw) if raw else None

    def login(self):
        try:
            auth = self._http("POST", f"{GUAC_URL}/api/tokens",
                              form={"username": GUAC_USER, "password": GUAC_PASS})
        except urllib.error.HTTPError as e:
            raise SystemExit(f"Falha no login do Guacamole como '{GUAC_USER}' "
                             f"(HTTP {e.code}). Confira GUAC_USER e GUAC_PASS.")
        except urllib.error.URLError as e:
            raise SystemExit(f"Nao foi possivel acessar {GUAC_URL}: {e.reason}")
        self.token, self.ds = auth["authToken"], auth["dataSource"]

    def call(self, method, path, body=None):
        if not self.token:
            self.login()
        url = f"{GUAC_URL}/api/session/data/{self.ds}{path}"
        try:
            return self._http(method, url, body=body, token=self.token)
        except urllib.error.HTTPError as e:
            if e.code not in (401, 403):
                raise
            self.login()   # token expirado: faz login de novo e repete
            return self._http(method, url, body=body, token=self.token)

    def find_connection(self, name):
        for c in (self.call("GET", "/connections") or {}).values():
            if c["name"].strip().upper() == name:
                return c["identifier"]
        return None

    def group_id(self, create=True):
        for g in (self.call("GET", "/connectionGroups") or {}).values():
            if g["name"] == CONN_GROUP:
                return g["identifier"]
        if not create:
            return None
        g = self.call("POST", "/connectionGroups",
                      {"parentIdentifier": "ROOT", "name": CONN_GROUP,
                       "type": "ORGANIZATIONAL", "attributes": {}})
        log(f"pasta criada no Guacamole: {CONN_GROUP}")
        return g["identifier"]

    def create_connection(self, name):
        params = {"hostname": fqdn(name), "port": RDP_PORT,
                  "security": RDP_SECURITY, "enable-wallpaper": "false"}
        if RDP_IGNORE_CERT:
            params["ignore-cert"] = "true"
        if PASS_CREDENTIALS:
            params["username"] = "${GUAC_USERNAME}"
            params["password"] = "${GUAC_PASSWORD}"
            if RDP_DOMAIN:
                params["domain"] = RDP_DOMAIN
        conn = self.call("POST", "/connections",
                         {"parentIdentifier": self.group_id(), "name": name,
                          "protocol": "rdp", "parameters": params, "attributes": {}})
        cid = conn["identifier"]
        if USER_GROUP:
            group = urllib.parse.quote(USER_GROUP, safe="")
            self.call("PATCH", f"/userGroups/{group}/permissions",
                      [{"op": "add", "path": f"/connectionPermissions/{cid}",
                        "value": "READ"}])
        return cid

    def client_url(self, cid):
        ident = base64.b64encode(f"{cid}\0c\0{self.ds}".encode()).decode()
        return f"{GUAC_PUBLIC_URL}/#/client/{urllib.parse.quote(ident, safe='')}"

    def get_or_create(self, name):
        with self.lock:
            cid = self.find_connection(name)
            if cid is not None:
                return self.client_url(cid), False
            if CHECK_DNS and not resolves(fqdn(name)):
                raise NotInDNS(fqdn(name))
            cid = self.create_connection(name)
            log(f"conexao criada: {name} -> {fqdn(name)}")
            return self.client_url(cid), True


# ------------------------------ utilitarios ------------------------------

def normalize(raw):
    return (raw or "").strip().split(".")[0].upper()


def fqdn(name):
    return f"{name.lower()}.{DOMAIN_DNS}" if DOMAIN_DNS else name.lower()


def resolves(host):
    try:
        socket.getaddrinfo(host, None)
        return True
    except socket.gaierror:
        return False


def allowed(ip):
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return any(addr in n for n in NETWORKS)


# ------------------------------ servidor web ------------------------------

API = Guacamole()


class Handler(BaseHTTPRequestHandler):
    server_version = "guac-glpi"

    def page(self, code, message):
        body = (f"<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'>"
                f"<title>Acesso remoto</title></head>"
                f"<body style='font-family:sans-serif;padding:2em;max-width:40em'>"
                f"<p>{html.escape(message)}</p>"
                f"<p><a href='{html.escape(GUAC_PUBLIC_URL)}/'>Abrir o Guacamole</a></p>"
                f"</body></html>").encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        url = urllib.parse.urlsplit(self.path)
        if url.path == "/health":
            return self.page(200, "ok")
        if url.path != "/":
            return self.page(404, "Pagina nao encontrada.")
        if not allowed(self.client_address[0]):
            return self.page(403, "Acesso nao permitido a partir deste endereco.")

        name = normalize(urllib.parse.parse_qs(url.query).get("host", [""])[0])
        if not name:
            return self.page(400, "Nenhum computador informado (use ?host=NOME).")
        if not VALID_NAME.match(name):
            return self.page(400, f"Nome de computador invalido: {name}")

        try:
            target, _ = API.get_or_create(name)
        except NotInDNS as e:
            return self.page(404, f"O computador {name} nao foi encontrado no DNS ({e}). "
                                  f"Verifique se ele esta ligado e no dominio.")
        except Exception as e:  # noqa: BLE001
            log(f"ERRO ao processar {name}: {e!r}")
            return self.page(502, f"Erro ao comunicar com o Guacamole: {e}")

        self.send_response(302)
        self.send_header("Location", target)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def log_message(self, fmt, *args):
        log(f"{self.client_address[0]} {fmt % args}")


def cmd_run():
    API.login()
    API.group_id()
    log(f"Ponte GLPI -> Guacamole ouvindo em {LISTEN_ADDR}:{LISTEN_PORT}")
    ThreadingHTTPServer((LISTEN_ADDR, LISTEN_PORT), Handler).serve_forever()


# ------------------------------ comandos ------------------------------

def check_config():
    if GUAC_PASS == "TROQUE_AQUI":
        raise SystemExit("Preencha GUAC_PASS no bloco CONFIGURE AQUI antes de continuar.")


def cmd_test(raw_name):
    check_config()
    API.login()
    log(f"[ok] login no Guacamole como '{GUAC_USER}' (datasource: {API.ds})")
    gid = API.group_id(create=False)
    log(f"[ok] pasta '{CONN_GROUP}' existe" if gid
        else f"[..] pasta '{CONN_GROUP}' ainda nao existe (sera criada na instalacao)")
    if not raw_name:
        return
    name = normalize(raw_name)
    if not VALID_NAME.match(name):
        raise SystemExit(f"[erro] nome invalido: {name}")
    cid = API.find_connection(name)
    if cid is not None:
        log(f"[ok] conexao '{name}' ja existe -> {API.client_url(cid)}")
        return
    host = fqdn(name)
    if resolves(host):
        log(f"[ok] {host} resolve no DNS deste servidor")
    else:
        log(f"[!!] {host} NAO resolve no DNS deste servidor"
            + (" (com CHECK_DNS=True a conexao nao sera criada)" if CHECK_DNS else ""))
    log(f"[..] conexao '{name}' nao existe: seria criada apontando para {host}:{RDP_PORT}")


def run(cmd):
    subprocess.run(cmd, check=True)


def cmd_install():
    if os.geteuid() != 0:
        raise SystemExit("Execute a instalacao como root (sudo).")
    check_config()
    API.login()
    API.group_id()
    log("[ok] acesso ao Guacamole confirmado")

    if subprocess.run(["id", SERVICE_USER], capture_output=True).returncode != 0:
        run(["useradd", "--system", "--no-create-home",
             "--shell", "/usr/sbin/nologin", SERVICE_USER])
    os.makedirs(INSTALL_DIR, exist_ok=True)
    shutil.copy2(os.path.abspath(__file__), INSTALL_FILE)
    shutil.chown(INSTALL_DIR, SERVICE_USER, SERVICE_USER)
    shutil.chown(INSTALL_FILE, SERVICE_USER, SERVICE_USER)
    os.chmod(INSTALL_DIR, 0o700)
    os.chmod(INSTALL_FILE, 0o600)   # o arquivo contem a senha do svc-sync

    with open(UNIT_FILE, "w") as f:
        f.write(f"""[Unit]
Description=Ponte GLPI -> Guacamole
After=network-online.target docker.service
Wants=network-online.target

[Service]
User={SERVICE_USER}
ExecStart={sys.executable} {INSTALL_FILE} run
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
""")
    run(["systemctl", "daemon-reload"])
    run(["systemctl", "enable", SERVICE])
    run(["systemctl", "restart", SERVICE])

    host = urllib.parse.urlsplit(GUAC_PUBLIC_URL).hostname
    log(f"""
[ok] Servico '{SERVICE}' instalado e em execucao.

Link externo para cadastrar no GLPI (Configurar > Links externos):
    http://{host}:{LISTEN_PORT}/?host=[NAME]

Log:            journalctl -u {SERVICE} -f
Mudou a config? Edite este arquivo e rode o install de novo.
""")


def cmd_uninstall():
    if os.geteuid() != 0:
        raise SystemExit("Execute como root (sudo).")
    subprocess.run(["systemctl", "disable", "--now", SERVICE])
    for path in (UNIT_FILE,):
        if os.path.exists(path):
            os.remove(path)
    shutil.rmtree(INSTALL_DIR, ignore_errors=True)
    run(["systemctl", "daemon-reload"])
    log("Servico removido. As conexoes criadas no Guacamole foram mantidas.")


if __name__ == "__main__":
    command = sys.argv[1] if len(sys.argv) > 1 else ""
    if command == "run":
        cmd_run()
    elif command == "test":
        cmd_test(sys.argv[2] if len(sys.argv) > 2 else "")
    elif command == "install":
        cmd_install()
    elif command == "uninstall":
        cmd_uninstall()
    else:
        print(__doc__)
